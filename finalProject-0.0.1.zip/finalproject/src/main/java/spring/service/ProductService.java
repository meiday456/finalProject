package spring.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;

import spring.entity.Product;

@Service
public interface ProductService {
	
	void addProduct(HttpServletRequest request2);
	List<Product>showProduct();
}
