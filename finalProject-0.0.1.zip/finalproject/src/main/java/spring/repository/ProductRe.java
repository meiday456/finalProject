package spring.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import spring.entity.Product;
@Repository
public interface ProductRe {
	
	void addProduct(Product product);
	List<Product>showProduct();
}
