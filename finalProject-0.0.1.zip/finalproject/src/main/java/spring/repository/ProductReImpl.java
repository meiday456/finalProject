package spring.repository;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import spring.entity.Product;

@Repository("productRe")
public class ProductReImpl implements ProductRe {

	@Autowired
	private SqlSessionTemplate sqlSession;
	
	
	@Override
	public void addProduct(Product product) {
		// TODO Auto-generated method stub
		sqlSession.insert("addProduct",product);
	}

	@Override
	public List<Product> showProduct() {
		// TODO Auto-generated method stub
		return null;
	}

}
