package spring.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import spring.service.ProductService;

@Controller
public class AdminController {
	
	@Autowired
	private ProductService productService;
	
	@RequestMapping("/addproduct")
	public String addProduct() {
		return "admin/addproduct";
	}
	@RequestMapping(value="/addproduct",method=RequestMethod.POST)
	public String addProductPost(HttpServletRequest request2) {
		productService.addProduct(request2);
		
		return "redirect:/admin";
	}
}
