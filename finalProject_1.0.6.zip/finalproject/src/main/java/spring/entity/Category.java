package spring.entity;

import lombok.Data;

@Data
public class Category {
	private int no;
	private String name;
	private int parentNo;
}
