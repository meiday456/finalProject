package spring.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Product {
	private int no;
	private String name;
	private int price;
	private int stock;
	private String event;
	private String status;
	private int score;
	private int category;
	private String reg;
	private String filename;
}
