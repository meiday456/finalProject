package spring.repository;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.mybatis.spring.SqlSessionTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import spring.entity.Category;
@Repository("categoryRe")
public class CategoryReImpl implements CategoryRe {
	
	private Logger log = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private SqlSessionTemplate sqlSession;
	
	//카테고리 추가
	@Override
	public void addFirstCategory(List<Category> list) {
		int no=0;
		int parent_no=0;
		Category overLapCheck;
		for(Category category : list) {
			no =sqlSession.selectOne("CategorySequnce");
			if(category.getName().equals(list.get(0).getName())) {
				//중복 검사를 먼저한다
				overLapCheck=sqlSession.selectOne("overLapCheck",category.getName());
				if(overLapCheck==null) {
					category.setNo(no);
					category.setParentNo(0);
					sqlSession.insert("addCategory", category);
				}else {
					no =overLapCheck.getNo();
				}
				
			}else {
				//하위 항목되 overlap을 확인한다
				overLapCheck=sqlSession.selectOne("overLapCheck",category.getName());
				if(overLapCheck==null) {
					category.setNo(no);
					category.setParentNo(parent_no);
					sqlSession.insert("addCategory", category);
				}else {
					no =overLapCheck.getNo();
				}
			}
			parent_no = no;
		}
	}

	//처음 카테고리 출력,표시
	@Override
	public List<Category> showFirctCategory() {
		List<Category>list =sqlSession.selectList("FirstLevelCategory");
		
		return list;
	}
	
	
	//하위 카테고리 출력용
	@Override
	public List<Category> showRowCategory(String name) {
		int no=sqlSession.selectOne("surchRowLevelcategory", name);
		return sqlSession.selectList("surchRowCategory",no);
	}

}
