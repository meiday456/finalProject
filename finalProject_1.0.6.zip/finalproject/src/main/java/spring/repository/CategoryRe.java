package spring.repository;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Repository;

import spring.entity.Category;

@Repository
public interface CategoryRe {
	void addFirstCategory(List<Category> list);
	List<Category> showFirctCategory();
	List<Category> showRowCategory(String name);
}
