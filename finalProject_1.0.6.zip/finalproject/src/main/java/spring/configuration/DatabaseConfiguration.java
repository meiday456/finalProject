package spring.configuration;

import javax.sql.DataSource;

import org.apache.commons.dbcp2.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;

@Configuration
//@PropertySource(value="file:src/main/webapp/WEB-INF/property/db.properties")
public class DatabaseConfiguration {
	
	//설정값을 database.properties에서 불러와서 적용하겠습니다
	//@PropertySource 설정이 필요
	//1. @Value로지정하여 설정
	//2. Environment 클래스를 이용하는 방법
	
//	@Value("database.driver")
//	private String driver;
	
//	@Autowired
//	private Environment env;
//	
//	@Bean
//	public DataSource dataSource() {
//		BasicDataSource dataSource = new BasicDataSource();
//		dataSource.setDriverClassName(driver);
//		dataSource.setUrl(env.getProperty("database.url"));
//		dataSource.setUsername(env.getProperty("database.username"));
//		dataSource.setPassword(env.getProperty("database.password"));
//		dataSource.setMaxTotal(Integer.parseInt(env.getProperty("database.max-action")));
//		dataSource.setMaxIdle(Integer.parseInt(env.getProperty("database.max-idle")));
//		dataSource.setMaxWaitMillis(Integer.parseInt(env.getProperty("database.max-wait")));
//		return dataSource;
//	}
//	
//	@Bean
//	public JdbcTemplate jdbcTemplate(DataSource dataSource) {//불러와진 dataSource가 있다면
//		JdbcTemplate template = new JdbcTemplate();			//여기에서 사용이 가능하다.
//		template.setDataSource(dataSource);
//		return template;
//	}
	
	@Bean
	public DataSource dataSource() {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setDriverClassName("oracle.jdbc.OracleDriver");
		dataSource.setUrl("jdbc:oracle:thin:@localhost:1521:xe");
		dataSource.setUsername("sw5");
		dataSource.setPassword("sw5");
		dataSource.setMaxTotal(20);
		dataSource.setMaxIdle(10);
		dataSource.setMaxWaitMillis(3000);
		return dataSource;
	}
	
	@Bean
	public JdbcTemplate jdbcTemplate(DataSource dataSource) {//불러와진 dataSource가 있다면
		JdbcTemplate template = new JdbcTemplate();			//여기에서 사용이 가능하다.
		template.setDataSource(dataSource);
		return template;
	}
}








