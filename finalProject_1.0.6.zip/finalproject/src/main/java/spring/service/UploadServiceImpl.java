package spring.service;

import java.io.File;
import java.io.IOException;

import javax.servlet.ServletContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service("uploadService")
public class UploadServiceImpl implements UploadService {
	
	private Logger log = LoggerFactory.getLogger(this.getClass());
	@Autowired
	private ServletContext application;

	@Override
	public void uploadFile(MultipartFile file) throws IllegalStateException, IOException {

		String path = application.getRealPath("/image");
		File target = new File(path,file.getOriginalFilename());
		file.transferTo(target);
		
	}

}
