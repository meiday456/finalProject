package spring.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import spring.entity.Product;
import spring.repository.ProductRe;

@Service("productService")
public class ProductServiceImpl implements ProductService {

	@Autowired
	private ProductRe productRe;
	
	@Override
	public void addProduct(HttpServletRequest request2,String filename) {
		Product product = new Product();
		product.setName(request2.getParameter("name"));
		product.setPrice(Integer.parseInt(request2.getParameter("price")));
		product.setStock(Integer.parseInt(request2.getParameter("stock")));
		product.setEvent(request2.getParameter("event"));
		product.setStatus(request2.getParameter("status"));
		product.setCategory(Integer.parseInt(request2.getParameter("category")));
		product.setFilename(filename);
		productRe.addProduct(product);
	}

	@Override
	public List<Product> showProduct() {
		return productRe.showProduct();
	}

	@Override
	public Product detailProduct(int no) {
		return productRe.detailProduct(no);
	}

}
