package spring.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;

import spring.entity.Category;

@Service
public interface CategoryService {
	void addCategory(HttpServletRequest request);
	List<Category> showFirstCategory();
	List<Category> showRowCategory(String name);
}
