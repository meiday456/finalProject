package spring.service;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import spring.entity.Category;
import spring.repository.CategoryRe;

@Service("categoryService")
public class CategoryServiceImpl implements CategoryService {

	private Logger log = LoggerFactory.getLogger(this.getClass());
	@Autowired
	private CategoryRe categoryRe;

	@Override
	public void addCategory(HttpServletRequest request) {
		List<Category> list = new ArrayList<>();
		int stock =1;
		if(request.getParameter("stock")!=null) {
			stock = Integer.parseInt(request.getParameter("stock"));
		}
		log.debug("클릭 항목수:{}",stock);
		for(int i=0;i<stock;i++) {
			Category category = new Category();
			category.setName(request.getParameter("name"+i));
			list.add(category);
		}
		log.debug("들어온 카테고리 정보:{}",list.toString());
	
		categoryRe.addFirstCategory(list);			
		
	}

	@Override
	public List<Category> showFirstCategory() {
		return categoryRe.showFirctCategory();
	}

	@Override
	public List<Category> showRowCategory(String name) {
		
		return categoryRe.showRowCategory(name);
	}


}
