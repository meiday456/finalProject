package spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import spring.entity.Product;
import spring.service.ProductService;

@Controller
public class ProductController {
	

	@Autowired
	private ProductService productService;
	
	@RequestMapping("/product")
	public String product(Model model) {
		List<Product> list=productService.showProduct();
		model.addAttribute("alllist",list);
		return "product/productmain";
	}

	@RequestMapping("/product_info")
	public String productInfo(@RequestParam int no,Model model) {
		model.addAttribute("product",productService.detailProduct(no));
		return "/product/product_detail";
	}
	
	@RequestMapping("/product_order")
	public String order(@RequestParam int no,@RequestParam int stock,Model model) {
		model.addAttribute("product",productService.detailProduct(no));
		model.addAttribute("stock",stock);
		return "/product/product_order";
	}
}
