package spring.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import spring.service.CategoryService;
import spring.service.ProductService;
import spring.service.UploadService;

@Controller
public class AdminController {
	
	private Logger log = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private ProductService productService;
	@Autowired
	private CategoryService categoryService;
	
	@Autowired
	private UploadService uploadService;
	
	//제품 추가
	@RequestMapping("/addproduct")
	public String addProduct() {
		return "admin/addproduct";
	}
	//제품추가 페이지(POST방식)
	@RequestMapping(value="/addproduct",method=RequestMethod.POST)
	@Transactional
	public String addProductPost(HttpServletRequest request2,@RequestParam MultipartFile file) {

//		log.debug("request2,{}",request2);
//		log.debug("file,{}",file);
//		log.debug("originalname{}",file.getOriginalFilename());
		productService.addProduct(request2,file.getOriginalFilename());
		try {
			uploadService.uploadFile(file);
		} catch (IllegalStateException | IOException e) {
			log.debug("에러:{}",e.getMessage());
			return "error";
		}
		
		return "redirect:/admin";
	}
	//카테고리 항목
	@RequestMapping("/addcategory")
	public String addCategory(Model model) {
		model.addAttribute("firstList",categoryService.showFirstCategory());
		return "admin/addcategory";
	}
	@RequestMapping(value="addcategory", method=RequestMethod.POST)
	public String addCategoryPost(HttpServletRequest request, Model model) {
		categoryService.addCategory(request);
		
		return "admin/addcategory";
	}
	
	//하위 카테고리 표시용 (비동기 통신)
	@RequestMapping("/test")
	public String test(@RequestParam String name, Model model) {
		model.addAttribute("rowList",categoryService.showRowCategory(name));
		return "ajax/test";
	}
	
}
