package finalproject;

import org.apache.ibatis.session.SqlSession;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mybatis.spring.SqlSessionTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import spring.entity.Product;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations= {"classpath:/spring/application-config.xml"})
public class Test01 {
	@Autowired
	private SqlSession sqlSession;
	
	private Logger log = LoggerFactory.getLogger(this.getClass());
	
	@Test
	public void test() {
		log.debug("야!{}",sqlSession);
		Product pro = new Product();
		pro.setName("testing1");
		pro.setPrice(1500);
		pro.setStock(10);
		pro.setEvent("신장개업");
		pro.setStatus("정상");
		pro.setScore(0);
		pro.setCategory(0);
		pro.setFilename("없음");
		sqlSession.insert("addProduct", pro);
	}
}
